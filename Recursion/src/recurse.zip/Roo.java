import java.util.List;


public class Roo {
	private List<Bar> gaw;

	public Roo(List<Bar> gaw) {
		super();
		this.gaw = gaw;
	}

	public List<Bar> getGaw() {
		return gaw;
	}

	public void setGaw(List<Bar> gaw) {
		this.gaw = gaw;
	}
}

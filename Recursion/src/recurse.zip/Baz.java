
public class Baz {
	private Goo goo;
	
	public Baz(Goo goo) {
		super();
		this.goo = goo;
	}

	public Goo getGoo() {
		return goo;
	}

	public void setGoo(Goo goo) {
		this.goo = goo;
	}
}

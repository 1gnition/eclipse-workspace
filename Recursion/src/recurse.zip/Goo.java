import java.util.List;


public class Goo {
	private List<List<Foo>> baw;

	public Goo(List<List<Foo>> baw) {
		super();
		this.baw = baw;
	}

	public List<List<Foo>> getBaw() {
		return baw;
	}

	public void setBaw(List<List<Foo>> baw) {
		this.baw = baw;
	}
}


public class Doo {
	private Roo roo;

	public Doo(Roo roo) {
		super();
		this.roo = roo;
	}

	public Roo getRoo() {
		return roo;
	}

	public void setRoo(Roo roo) {
		this.roo = roo;
	}
}

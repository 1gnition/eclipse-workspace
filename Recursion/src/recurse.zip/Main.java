import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;


public class Main {
	public static void main(String[] args) throws Exception {
		List<String> innerList1 = new ArrayList<>();
		innerList1.add("1");
		innerList1.add("2");
		innerList1.add("3");

		List<String> innerList2 = new ArrayList<>();
		innerList2.add("a");
		innerList2.add("b");
		innerList2.add("c");
		
		List<List<String>> list1 = new ArrayList<List<String>>();
		list1.add(innerList1);
		list1.add(innerList2);
		
		List<List<Bar>> list2 = new ArrayList<List<Bar>>();
		
		List<Bar> innerList11 = new ArrayList<Bar>();
		innerList11.add(new Bar("1"));
		innerList11.add(new Bar("2"));
		innerList11.add(new Bar("3"));

		List<Bar> innerList12 = new ArrayList<Bar>();
		innerList12.add(new Bar("a"));
		innerList12.add(new Bar("b"));
		innerList12.add(new Bar("c"));
		
		list2.add(innerList11);
		list2.add(innerList12);
		
		List<List<Foo>> list3 = new ArrayList<List<Foo>>();
		
		List<Foo> innerList21 = new ArrayList<Foo>();
		innerList21.add(new Foo(new Bar("1")));
		innerList21.add(new Foo(new Bar("2")));
		innerList21.add(new Foo(new Bar("3")));

		List<Foo> innerList22 = new ArrayList<Foo>();
		innerList22.add(new Foo(new Bar("a")));
		innerList22.add(new Foo(new Bar("b")));
		innerList22.add(new Foo(new Bar("c")));
		
		list3.add(innerList21);
		list3.add(innerList22);
		
//		System.out.println(list1);
//		System.out.println(list2);
//		System.out.println(list3);
		
//		recurse(list1, toStack("[[]]"));
//		recurse(list2, toStack("[[str]]"));
//		recurse(list3, toStack("[[bar.str]]"));
//		Foo foo = new Foo(new Bar("hi"));
//		recurse(foo, toStack("bar.str"));
		
		
		recurse2(list1, toStack2("[].[]"));
		System.out.println("----------");
		recurse2(list2, toStack2("[].[].str"));
		System.out.println("----------");
		recurse2(list3, toStack2("[].[].bar.str"));
		System.out.println("----------");
		Foo foo = new Foo(new Bar("hi"));
		recurse2(foo, toStack2("bar.str"));
		System.out.println("----------");
		Baz baz = new Baz(new Goo(list3));
		recurse2(baz, toStack2("goo.baw.[].[].bar.str"));
		Doo doo = new Doo(new Roo(innerList11));
		recurse2(doo, toStack2("roo.gaw.[].str"));
		
	}
	
	private static Object getField(Object obj, String fieldName) throws Exception {
		Class<?> clazz = obj.getClass();
		String getField = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
		Method method = clazz.getMethod(getField);
		Object field = method.invoke(obj);
		return field;
	}
	
	private static Stack<String> toStack(String path) {
		String[] parts;
		if (!inside('[', path, ']')) {
			parts = path.split("\\.");
		} else {
			parts = new String[]{path};
		}
		ArrayList<String> list = new ArrayList<String>(Arrays.asList(parts));
		Collections.reverse(list);
		Stack<String> stack = new Stack<String>();
		stack.addAll(list);
		return stack;
	}
	
	private static Stack<String> toStack2(String path) {
		String[] parts = path.split("\\.");
		ArrayList<String> list = new ArrayList<String>(Arrays.asList(parts));
		Collections.reverse(list);
		Stack<String> stack = new Stack<String>();
		stack.addAll(list);
		return stack;
	}
	
	private static void recurse(Object obj, Stack<String> stack) throws Exception {
		
		Stack<String> stack2 = (Stack<String>) stack.clone();
		
		if (stack2.isEmpty()) {
			System.out.println((String) obj);
			return;
		}
		
		String fieldName = stack2.pop();
		
		if (inside('[', fieldName, ']')) {
			fieldName = fieldName.substring(1, fieldName.length()-1);
			if (!fieldName.isEmpty()) {
				stack2.push(fieldName);
			}
			for (Object item : (List) obj) {
				recurse(item, stack2);
			}
		} else {
			if (!fieldName.isEmpty()) {
				stack2 = toStack(fieldName);
				fieldName = stack2.pop();
				Object field = getField(obj, fieldName);
				recurse(field, stack2);
			}
		}
	}
	
	private static void recurse2(Object obj, Stack<String> stack) throws Exception {

		Stack<String> stack2 = (Stack<String>) stack.clone();

		if (stack2.isEmpty()) {
			System.out.println((String) obj);
			return;
		}
		
		String fieldName = stack2.pop();
		
		if (fieldName.equals("[]")) {
			for (Object item : (List) obj) {
				recurse2(item, stack2);
			}
		} else {
			obj = getField(obj, fieldName);
			recurse2(obj, stack2);
		}

	}

	private static boolean inside(char lhs, String field, char rhs) {
		return (field.charAt(0) == lhs) && (field.charAt(field.length()-1) == rhs);
	}
	
	

}
